import gradio as gr
import tensorflow as tf
from tensorflow import keras
import numpy as np
import cv2
from PIL import Image

# Load pre-trained EfficientNet model
base_model = keras.applications.EfficientNetB0(weights='imagenet', include_top=False, input_shape=(224, 224, 3))
x = keras.layers.GlobalAveragePooling2D()(base_model.output)
x = keras.layers.Dense(1024, activation='relu')(x)
x = keras.layers.Dropout(0.5)(x)
output = keras.layers.Dense(1, activation='sigmoid')(x)
model = keras.models.Model(inputs=base_model.input, outputs=output)

# Load fine-tuned weights (you'll need to have these)
# model.load_weights('efficientnet_deepfake_weights.h5')

# Freeze the base model layers
for layer in base_model.layers:
    layer.trainable = False

# Define image preprocessing
def preprocess_image(image):
    image = cv2.resize(image, (224, 224))
    image = keras.applications.efficientnet.preprocess_input(image)
    return np.expand_dims(image, axis=0)

def predict_image(image):
    if image is None:
        return "No image uploaded"
    img = Image.fromarray(image).convert('RGB')
    img_array = np.array(img)
    preprocessed_img = preprocess_image(img_array)
    
    prediction = model.predict(preprocessed_img)[0][0]
    result = "Deepfake" if prediction > 0.5 else "Original"
    return f"{result} (Confidence: {prediction:.2f})"

def predict_video(video):
    if video is None:
        return "No video uploaded"
    cap = cv2.VideoCapture(video)
    frame_count = 0
    total_probability = 0
    
    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break
        
        frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        preprocessed_frame = preprocess_image(frame_rgb)
        prediction = model.predict(preprocessed_frame)[0][0]
        
        total_probability += prediction
        frame_count += 1
        
        if frame_count >= 100:  # Limit to 100 frames for faster processing
            break
    
    cap.release()
    
    if frame_count > 0:
        avg_probability = total_probability / frame_count
        result = "Deepfake" if avg_probability > 0.5 else "Original"
        return f"{result} (Average Confidence: {avg_probability:.2f})"
    else:
        return "Error processing video"

# Define Gradio interface
with gr.Blocks() as demo:
    gr.Markdown("# Deepfake Detector using EfficientNet")
    
    with gr.Tab("Image Detection"):
        image_input = gr.Image(label="Upload Image")
        image_output = gr.Text(label="Result")
        image_button = gr.Button("Detect Deepfake in Image")
    
    with gr.Tab("Video Detection"):
        video_input = gr.Video(label="Upload Video")
        video_output = gr.Text(label="Result")
        video_button = gr.Button("Detect Deepfake in Video")
    
    image_button.click(predict_image, inputs=image_input, outputs=image_output)
    video_button.click(predict_video, inputs=video_input, outputs=video_output)

# Launch the application
demo.launch()
